
number plate - v3 tr
==============================

This dataset was exported via roboflow.ai on March 18, 2022 at 8:18 AM GMT

It includes 1195 images.
Number-plate are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Resize to 256x256 (Stretch)
* Grayscale (CRT phosphor)

No image augmentation techniques were applied.


